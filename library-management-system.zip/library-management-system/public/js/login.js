let role = 'student';

const form = document.getElementById('login-form');
const errorBox = document.getElementById('login-error');
const submit = form.querySelector('button[type="submit"]');

// Already signed in? Go straight to the right page.
if (store.token && store.user) {
  location.replace(store.user.role === 'librarian' ? '/librarian.html' : '/student.html');
}

document.querySelectorAll('.seg button').forEach((btn) => {
  btn.addEventListener('click', () => {
    role = btn.dataset.role;
    document.querySelectorAll('.seg button').forEach((b) => b.setAttribute('aria-pressed', String(b === btn)));
    submit.textContent = `Sign in as ${role}`;
    errorBox.textContent = '';
  });
});

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errorBox.textContent = '';
  submit.disabled = true;
  try {
    const data = await api('/auth/login', {
      method: 'POST',
      noRedirect: true,
      body: { email: form.email.value, password: form.password.value, role },
    });
    store.set(data.token, data.user);
    location.href = data.user.role === 'librarian' ? '/librarian.html' : '/student.html';
  } catch (err) {
    errorBox.textContent = err.message;
    submit.disabled = false;
  }
});

loadRules().then((r) => {
  document.getElementById('r-days').textContent = `${r.loanDays} days`;
  document.getElementById('r-max').textContent = r.maxBooks;
  document.getElementById('r-reward').textContent = `+${r.rewardPoints} pts`;
  document.getElementById('r-fine').textContent = `${r.currency}${r.finePerDay} / day`;
});
