// Shared helpers used by every page.
const store = {
  get token() { return localStorage.getItem('lib_token'); },
  get user() {
    try { return JSON.parse(localStorage.getItem('lib_user') || 'null'); } catch (e) { return null; }
  },
  set(token, user) {
    localStorage.setItem('lib_token', token);
    localStorage.setItem('lib_user', JSON.stringify(user));
  },
  setUser(user) { localStorage.setItem('lib_user', JSON.stringify(user)); },
  clear() { localStorage.removeItem('lib_token'); localStorage.removeItem('lib_user'); },
};

async function api(path, { method = 'GET', body, noRedirect = false } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (store.token) headers.Authorization = `Bearer ${store.token}`;

  const res = await fetch(`/api${path}`, {
    method,
    headers,
    body: body === undefined ? undefined : JSON.stringify(body),
  });

  let data = null;
  try { data = await res.json(); } catch (e) { /* empty body */ }

  if (res.status === 401 && !noRedirect) {
    store.clear();
    location.href = '/';
    throw new Error((data && data.error) || 'Please sign in.');
  }
  if (!res.ok) throw new Error((data && data.error) || 'Something went wrong. Try again.');
  return data;
}

// Keeps a page private to one role.
function guard(role) {
  const user = store.user;
  if (!store.token || !user || user.role !== role) {
    location.href = '/';
    return null;
  }
  return user;
}

function logout() { store.clear(); location.href = '/'; }

let RULES = { loanDays: 14, maxBooks: 3, finePerDay: 5, rewardPoints: 10, currency: '₹' };
async function loadRules() {
  try { RULES = await api('/config', { noRedirect: true }); } catch (e) { /* keep defaults */ }
  return RULES;
}

const money = (n) => `${RULES.currency}${Number(n || 0)}`;

function esc(value) {
  return String(value ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function fmtDate(d) {
  if (!d) return '–';
  const date = new Date(d.length === 10 ? `${d}T00:00:00` : d);
  return date.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
}

function fmtDateTime(d) {
  return new Date(d).toLocaleString(undefined, { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
}

function toast(message, kind = '') {
  let box = document.getElementById('toasts');
  if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.setAttribute('role', 'status');
  el.textContent = message;
  box.appendChild(el);
  setTimeout(() => el.remove(), 4500);
}

// Runs an async action and shows any error as a toast.
async function run(action, successMessage, kind = '') {
  try {
    const result = await action();
    if (successMessage) toast(typeof successMessage === 'function' ? successMessage(result) : successMessage, kind);
    return result;
  } catch (err) {
    toast(err.message, 'error');
    return undefined;
  }
}

// Modal with a form. onSubmit receives the form values as an object.
function openModal(title, fieldsHtml, onSubmit, submitLabel = 'Save') {
  const root = document.getElementById('modal-root');
  root.innerHTML = `
    <div class="modal-backdrop">
      <div class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <h2 id="modal-title">${esc(title)}</h2>
        <form id="modal-form" novalidate>
          ${fieldsHtml}
          <p class="form-error" id="modal-error" role="alert"></p>
          <div class="modal-actions">
            <button type="button" class="btn ghost" data-close>Cancel</button>
            <button type="submit" class="btn primary">${esc(submitLabel)}</button>
          </div>
        </form>
      </div>
    </div>`;

  const close = () => { root.innerHTML = ''; document.removeEventListener('keydown', onKey); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  root.querySelector('[data-close]').addEventListener('click', close);
  root.querySelector('.modal-backdrop').addEventListener('mousedown', (e) => { if (e.target.classList.contains('modal-backdrop')) close(); });

  const form = root.querySelector('#modal-form');
  const first = form.querySelector('input, select, textarea');
  if (first) first.focus();

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const values = Object.fromEntries(new FormData(form).entries());
    try {
      await onSubmit(values);
      close();
    } catch (err) {
      root.querySelector('#modal-error').textContent = err.message;
    }
  });
}

// Wires a tab group: buttons carry data-tab, panels are elements with id "tab-<name>".
function setupTabs(container, onShow) {
  const buttons = [...container.querySelectorAll('[data-tab]')];
  const show = (name) => {
    buttons.forEach((b) => b.setAttribute('aria-selected', String(b.dataset.tab === name)));
    document.querySelectorAll('[id^="tab-"]').forEach((p) => { p.hidden = p.id !== `tab-${name}`; });
    onShow(name);
  };
  buttons.forEach((b) => b.addEventListener('click', () => show(b.dataset.tab)));
  return show;
}
