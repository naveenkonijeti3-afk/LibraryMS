const me = guard('librarian');
const $ = (id) => document.getElementById(id);

document.getElementById('who').textContent = me ? me.name : '';
document.getElementById('logout').addEventListener('click', logout);

const view = (name) => $(`tab-${name}`);
let borrowalFilter = 'borrowed';
let bookFilter = { q: '', section: '' };

// ---------- Dashboard ----------
async function loadDashboard() {
  const s = await api('/stats');
  view('dashboard').innerHTML = `
    <div class="view-head"><h2>Dashboard</h2></div>
    <div class="summary">
      <div><div class="num">${s.titles}</div><div class="lbl">Book titles</div></div>
      <div><div class="num">${s.available} / ${s.copies}</div><div class="lbl">Copies on the shelf</div></div>
      <div><div class="num">${s.onLoan}</div><div class="lbl">Books on loan</div></div>
      <div class="${s.overdue ? 'warn' : ''}"><div class="num">${s.overdue}</div><div class="lbl">Overdue</div></div>
      <div class="${s.unpaidFines ? 'warn' : ''}"><div class="num">${money(s.unpaidFines)}</div><div class="lbl">Unpaid fines</div></div>
      <div><div class="num">${s.students}</div><div class="lbl">Students</div></div>
      <div><div class="num">${s.borrowedToday}</div><div class="lbl">Borrowed today</div></div>
      <div><div class="num">${s.returnedToday}</div><div class="lbl">Returned today</div></div>
    </div>
    <h3>Stock by section</h3>
    <div class="panel table-wrap">
      ${s.sections.length ? `<table>
        <thead><tr><th>Section</th><th>Titles</th><th>Total copies</th><th>Available</th><th>On loan</th></tr></thead>
        <tbody>${s.sections.map((x) => `
          <tr><td><strong>${esc(x.name)}</strong></td><td>${x.titles}</td><td>${x.total_copies}</td>
              <td>${x.available_copies}</td><td>${x.total_copies - x.available_copies}</td></tr>`).join('')}
        </tbody></table>` : '<div class="empty">No sections yet. Add one under Sections.</div>'}
    </div>`;
}

// ---------- Books ----------
async function loadBooks() {
  const sections = await api('/sections');
  const params = new URLSearchParams();
  if (bookFilter.q) params.set('q', bookFilter.q);
  if (bookFilter.section) params.set('section', bookFilter.section);
  const books = await api(`/books?${params}`);

  view('books').innerHTML = `
    <div class="view-head"><h2>Books</h2><button class="btn primary" id="add-book">Add book</button></div>
    <div class="filters">
      <input id="book-q" type="search" placeholder="Search title, author or ISBN" value="${esc(bookFilter.q)}" aria-label="Search books" />
      <select id="book-section" aria-label="Filter by section">
        <option value="">All sections</option>
        ${sections.map((s) => `<option value="${s.id}" ${String(s.id) === String(bookFilter.section) ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}
      </select>
    </div>
    <div class="panel table-wrap">
      ${books.length ? `<table>
        <thead><tr><th>Title</th><th>Author</th><th>Section</th><th>ISBN</th><th>Available</th><th></th></tr></thead>
        <tbody>${books.map((b) => `
          <tr>
            <td><strong>${esc(b.title)}</strong></td>
            <td>${esc(b.author)}</td>
            <td>${esc(b.section_name)}</td>
            <td>${esc(b.isbn || '–')}</td>
            <td>${b.available_copies} / ${b.total_copies}</td>
            <td class="actions">
              <button class="btn small" data-edit="${b.id}">Edit</button>
              <button class="btn small danger" data-delete="${b.id}">Remove</button>
            </td>
          </tr>`).join('')}
        </tbody></table>` : '<div class="empty">No books found. Add your first book, or clear the filters.</div>'}
    </div>`;

  let timer;
  $('book-q').addEventListener('input', (e) => {
    clearTimeout(timer);
    timer = setTimeout(() => { bookFilter.q = e.target.value.trim(); loadBooks(); }, 300);
  });
  $('book-section').addEventListener('change', (e) => { bookFilter.section = e.target.value; loadBooks(); });
  $('add-book').addEventListener('click', () => bookForm(null, sections));

  view('books').querySelectorAll('[data-edit]').forEach((btn) =>
    btn.addEventListener('click', () => bookForm(books.find((b) => b.id === Number(btn.dataset.edit)), sections)));
  view('books').querySelectorAll('[data-delete]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const b = books.find((x) => x.id === Number(btn.dataset.delete));
      if (!confirm(`Remove "${b.title}" from the library?`)) return;
      await run(() => api(`/books/${b.id}`, { method: 'DELETE' }), 'Book removed');
      loadBooks();
    }));
}

function bookForm(book, sections) {
  if (!sections.length) return toast('Add a section first, then add books to it.', 'error');
  const v = book || { title: '', author: '', isbn: '', section_id: '', total_copies: 1 };
  openModal(
    book ? 'Edit book' : 'Add book',
    `<div class="field"><label for="f-title">Title</label><input id="f-title" name="title" value="${esc(v.title)}" required /></div>
     <div class="field"><label for="f-author">Author</label><input id="f-author" name="author" value="${esc(v.author)}" required /></div>
     <div class="row2">
       <div class="field"><label for="f-section">Section</label>
         <select id="f-section" name="section_id" required>
           ${sections.map((s) => `<option value="${s.id}" ${s.id === v.section_id ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}
         </select></div>
       <div class="field"><label for="f-copies">Total copies</label><input id="f-copies" name="total_copies" type="number" min="0" value="${v.total_copies}" required /></div>
     </div>
     <div class="field"><label for="f-isbn">ISBN <span class="hint">(optional)</span></label><input id="f-isbn" name="isbn" value="${esc(v.isbn || '')}" /></div>`,
    async (data) => {
      const body = { ...data, section_id: Number(data.section_id), total_copies: Number(data.total_copies) };
      await api(book ? `/books/${book.id}` : '/books', { method: book ? 'PUT' : 'POST', body });
      toast(book ? 'Book updated' : 'Book added');
      loadBooks();
    },
    book ? 'Save changes' : 'Add book'
  );
}

// ---------- Sections ----------
async function loadSections() {
  const sections = await api('/sections');
  view('sections').innerHTML = `
    <div class="view-head"><h2>Sections</h2><button class="btn primary" id="add-section">Add section</button></div>
    <div class="panel table-wrap">
      ${sections.length ? `<table>
        <thead><tr><th>Section</th><th>Description</th><th>Titles</th><th>Copies</th><th>Available</th><th></th></tr></thead>
        <tbody>${sections.map((s) => `
          <tr>
            <td><strong>${esc(s.name)}</strong></td><td>${esc(s.description || '–')}</td>
            <td>${s.titles}</td><td>${s.total_copies}</td><td>${s.available_copies}</td>
            <td class="actions"><button class="btn small danger" data-delete="${s.id}">Remove</button></td>
          </tr>`).join('')}
        </tbody></table>` : '<div class="empty">No sections yet. Add sections like Fiction or Science to organise books.</div>'}
    </div>`;

  $('add-section').addEventListener('click', () =>
    openModal('Add section',
      `<div class="field"><label for="s-name">Name</label><input id="s-name" name="name" required /></div>
       <div class="field"><label for="s-desc">Description <span class="hint">(optional)</span></label><input id="s-desc" name="description" /></div>`,
      async (data) => { await api('/sections', { method: 'POST', body: data }); toast('Section added'); loadSections(); },
      'Add section'));

  view('sections').querySelectorAll('[data-delete]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const s = sections.find((x) => x.id === Number(btn.dataset.delete));
      if (!confirm(`Remove the "${s.name}" section?`)) return;
      await run(() => api(`/sections/${s.id}`, { method: 'DELETE' }), 'Section removed');
      loadSections();
    }));
}

// ---------- Students ----------
async function loadStudents() {
  const students = await api('/students');
  view('students').innerHTML = `
    <div class="view-head"><h2>Students</h2><button class="btn primary" id="add-student">Add student</button></div>
    <div class="panel table-wrap">
      ${students.length ? `<table>
        <thead><tr><th>Name</th><th>Roll no.</th><th>Email</th><th>Books out</th><th>Points</th><th>Unpaid fines</th><th></th></tr></thead>
        <tbody>${students.map((s) => `
          <tr>
            <td><strong>${esc(s.name)}</strong></td><td>${esc(s.roll_no || '–')}</td><td>${esc(s.email)}</td>
            <td>${s.active_borrowals}</td>
            <td><span class="badge reward">${s.reward_points}</span></td>
            <td>${s.unpaid_fines > 0 ? `<span class="badge late">${money(s.unpaid_fines)}</span>` : '–'}</td>
            <td class="actions"><button class="btn small danger" data-delete="${s.id}">Remove</button></td>
          </tr>`).join('')}
        </tbody></table>` : '<div class="empty">No students yet. Add a student so they can sign in and borrow books.</div>'}
    </div>`;

  $('add-student').addEventListener('click', () =>
    openModal('Add student',
      `<div class="field"><label for="st-name">Full name</label><input id="st-name" name="name" required /></div>
       <div class="row2">
         <div class="field"><label for="st-roll">Roll number</label><input id="st-roll" name="roll_no" /></div>
         <div class="field"><label for="st-email">Email</label><input id="st-email" name="email" type="email" required /></div>
       </div>
       <div class="field"><label for="st-pass">Starting password</label><input id="st-pass" name="password" type="text" minlength="6" required />
         <span class="hint">At least 6 characters. Share it with the student.</span></div>`,
      async (data) => { await api('/students', { method: 'POST', body: data }); toast('Student added'); loadStudents(); },
      'Add student'));

  view('students').querySelectorAll('[data-delete]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const s = students.find((x) => x.id === Number(btn.dataset.delete));
      if (!confirm(`Remove ${s.name}? Their borrowing history will be deleted too.`)) return;
      await run(() => api(`/students/${s.id}`, { method: 'DELETE' }), 'Student removed');
      loadStudents();
    }));
}

// ---------- Borrowals & returns ----------
async function loadBorrowals() {
  const rows = await api(`/borrowals?status=${borrowalFilter}`);
  view('borrowals').innerHTML = `
    <div class="view-head">
      <h2>Borrowals &amp; returns</h2>
      <select id="b-filter" aria-label="Filter borrowals" style="width:auto">
        ${[['borrowed', 'On loan'], ['overdue', 'Overdue'], ['returned', 'Returned'], ['all', 'All']]
          .map(([v, l]) => `<option value="${v}" ${v === borrowalFilter ? 'selected' : ''}>${l}</option>`).join('')}
      </select>
      <button class="btn primary" id="issue-book">Issue a book</button>
    </div>
    <div class="panel table-wrap">
      ${rows.length ? `<table>
        <thead><tr><th>Student</th><th>Book</th><th>Borrowed</th><th>Due</th><th>Returned</th><th>Status</th><th></th></tr></thead>
        <tbody>${rows.map((r) => `
          <tr>
            <td><strong>${esc(r.student_name)}</strong><div class="hint">${esc(r.student_roll || '')}</div></td>
            <td>${esc(r.book_title)}<div class="hint">${esc(r.section_name)}</div></td>
            <td>${fmtDate(r.borrow_date)}</td>
            <td>${fmtDate(r.due_date)}</td>
            <td>${fmtDate(r.return_date)}</td>
            <td>${statusBadge(r)}</td>
            <td class="actions">${actionButtons(r)}</td>
          </tr>`).join('')}
        </tbody></table>` : '<div class="empty">Nothing here for this filter.</div>'}
    </div>`;

  $('b-filter').addEventListener('change', (e) => { borrowalFilter = e.target.value; loadBorrowals(); });
  $('issue-book').addEventListener('click', issueForm);

  view('borrowals').querySelectorAll('[data-return]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      const r = await run(
        () => api(`/borrowals/${btn.dataset.return}/return`, { method: 'POST' }),
        (res) => res.reward ? `Returned on time. ${res.reward} points awarded.` : `Returned ${res.lateDays} day(s) late. Fine ${money(res.fine)}.`
      );
      if (r) loadBorrowals();
    }));
  view('borrowals').querySelectorAll('[data-pay]').forEach((btn) =>
    btn.addEventListener('click', async () => {
      if (!confirm('Confirm the fine has been collected?')) return;
      const r = await run(() => api(`/borrowals/${btn.dataset.pay}/pay-fine`, { method: 'POST' }), 'Fine marked as paid');
      if (r) loadBorrowals();
    }));
}

function statusBadge(r) {
  if (r.status === 'borrowed') {
    return r.is_overdue
      ? `<span class="badge late">${r.days_overdue} day(s) late · ${money(r.current_fine)}</span>`
      : '<span class="badge">On loan</span>';
  }
  if (r.reward_earned) return `<span class="badge reward">On time · +${r.reward_earned} pts</span>`;
  return r.fine_paid
    ? `<span class="badge ok">Fine ${money(r.fine)} paid</span>`
    : `<span class="badge late">Fine ${money(r.fine)} unpaid</span>`;
}

function actionButtons(r) {
  if (r.status === 'borrowed') return `<button class="btn small primary" data-return="${r.id}">Accept return</button>`;
  if (r.fine > 0 && !r.fine_paid) return `<button class="btn small" data-pay="${r.id}">Mark fine paid</button>`;
  return '';
}

async function issueForm() {
  const [students, books] = await Promise.all([api('/students'), api('/books')]);
  const available = books.filter((b) => b.available_copies > 0);
  if (!students.length || !available.length) return toast('You need at least one student and one available book.', 'error');

  openModal('Issue a book',
    `<div class="field"><label for="i-student">Student</label>
       <select id="i-student" name="studentId">${students.map((s) => `<option value="${s.id}">${esc(s.name)}${s.roll_no ? ' (' + esc(s.roll_no) + ')' : ''}</option>`).join('')}</select></div>
     <div class="field"><label for="i-book">Book</label>
       <select id="i-book" name="bookId">${available.map((b) => `<option value="${b.id}">${esc(b.title)} – ${b.available_copies} available</option>`).join('')}</select></div>
     <p class="hint">Due in ${RULES.loanDays} days. Late returns cost ${money(RULES.finePerDay)} per day.</p>`,
    async (data) => {
      const r = await api('/borrowals', { method: 'POST', body: { studentId: Number(data.studentId), bookId: Number(data.bookId) } });
      toast(`Issued "${r.title}". Due ${fmtDate(r.dueDate)}.`);
      loadBorrowals();
    },
    'Issue book');
}

// ---------- Activity log (MongoDB) ----------
const ACTION_LABELS = {
  login: 'signed in', book_borrowed: 'borrowed a book', book_returned: 'returned a book', fine_paid: 'fine paid',
  book_added: 'added a book', book_updated: 'updated a book', book_removed: 'removed a book',
  section_added: 'added a section', section_removed: 'removed a section',
  student_added: 'added a student', student_removed: 'removed a student',
};

function describe(item) {
  const d = item.details || {};
  const bits = [d.book || d.title, d.student || d.name, d.lateDays ? `${d.lateDays} day(s) late` : '', d.fine ? `fine ${money(d.fine)}` : '', d.reward ? `+${d.reward} pts` : '']
    .filter(Boolean);
  return bits.join(' · ');
}

async function loadActivity() {
  const data = await api('/activity');
  view('activity').innerHTML = `
    <div class="view-head"><h2>Activity log</h2></div>
    <div class="panel">
      ${!data.available
        ? '<div class="empty">The activity log needs MongoDB. Start MongoDB or set MONGO_URI in .env, then restart the server.</div>'
        : data.items.length
          ? `<ul class="note-list">${data.items.map((i) => `
              <li><span class="badge">${esc(i.role || 'system')}</span>
                  <span><strong>${esc(i.actorName || 'Someone')}</strong> ${esc(ACTION_LABELS[i.action] || i.action)}
                  <span class="hint">${esc(describe(i))}</span></span>
                  <time>${fmtDateTime(i.createdAt)}</time></li>`).join('')}</ul>`
          : '<div class="empty">No activity recorded yet.</div>'}
    </div>`;
}

// ---------- Navigation ----------
const loaders = { dashboard: loadDashboard, books: loadBooks, sections: loadSections, students: loadStudents, borrowals: loadBorrowals, activity: loadActivity };
const show = setupTabs($('nav'), (name) => run(loaders[name]));

(async function start() {
  if (!me) return;
  await loadRules();
  show('dashboard');
})();
