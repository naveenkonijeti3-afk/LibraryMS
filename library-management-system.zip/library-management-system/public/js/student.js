const me = guard('student');
let loans = [];

document.getElementById('who').textContent = me ? `${me.name}${me.roll_no ? ' · ' + me.roll_no : ''}` : '';
document.getElementById('logout').addEventListener('click', logout);

const $ = (id) => document.getElementById(id);

// ---------- Summary + points ----------
async function refreshUser() {
  const { user } = await api('/auth/me');
  store.setUser(user);
  $('points').textContent = `${user.reward_points} points`;
  return user;
}

function renderSummary(user) {
  const active = loans.filter((l) => l.status === 'borrowed');
  const overdue = active.filter((l) => l.is_overdue);
  const owed = loans.filter((l) => l.status === 'returned' && l.fine > 0 && !l.fine_paid).reduce((s, l) => s + l.fine, 0);
  const accruing = overdue.reduce((s, l) => s + l.current_fine, 0);

  $('summary').innerHTML = `
    <div class="good"><div class="num">${user.reward_points}</div><div class="lbl">Reward points</div></div>
    <div><div class="num">${active.length} / ${RULES.maxBooks}</div><div class="lbl">Books borrowed</div></div>
    <div class="${overdue.length ? 'warn' : ''}"><div class="num">${overdue.length}</div><div class="lbl">Overdue books</div></div>
    <div class="${owed + accruing > 0 ? 'warn' : ''}"><div class="num">${money(owed + accruing)}</div><div class="lbl">Fines due</div></div>`;
}

// ---------- Browse ----------
async function loadSections() {
  const sections = await api('/sections');
  $('section-filter').insertAdjacentHTML(
    'beforeend',
    sections.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join('')
  );
}

async function loadBooks() {
  const params = new URLSearchParams();
  if ($('search').value.trim()) params.set('q', $('search').value.trim());
  if ($('section-filter').value) params.set('section', $('section-filter').value);
  const books = await api(`/books?${params}`);

  const held = new Set(loans.filter((l) => l.status === 'borrowed').map((l) => l.book_id));

  $('book-list').innerHTML = books.length
    ? books.map((b) => {
        const has = held.has(b.id);
        const out = b.available_copies < 1;
        return `
        <li class="book-row">
          <div>
            <div class="title">${esc(b.title)}</div>
            <div class="meta">${esc(b.author)} · ${esc(b.section_name)}</div>
            <div class="meta">${out ? '<span class="badge out">All copies on loan</span>' : `<span class="badge ok">${b.available_copies} of ${b.total_copies} available</span>`}</div>
          </div>
          <button class="btn primary small" data-borrow="${b.id}" ${out || has ? 'disabled' : ''}>${has ? 'You have this' : 'Borrow'}</button>
        </li>`;
      }).join('')
    : '<li class="empty">No books match your search. Try a different title, author or section.</li>';
}

$('book-list').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-borrow]');
  if (!btn) return;
  btn.disabled = true;
  const result = await run(
    () => api('/borrowals', { method: 'POST', body: { bookId: Number(btn.dataset.borrow) } }),
    (r) => `Borrowed "${r.title}". Return by ${fmtDate(r.dueDate)}.`
  );
  await reloadAll();
  if (!result) btn.disabled = false;
});

let searchTimer;
$('search').addEventListener('input', () => { clearTimeout(searchTimer); searchTimer = setTimeout(loadBooks, 250); });
$('section-filter').addEventListener('change', loadBooks);

// ---------- My books ----------
async function loadLoans() {
  loans = await api('/borrowals/mine');
  const active = loans.filter((l) => l.status === 'borrowed');
  const history = loans.filter((l) => l.status === 'returned');

  $('active-loans').innerHTML = active.length
    ? `<table>
        <thead><tr><th>Book</th><th>Borrowed</th><th>Due</th><th>Status</th><th></th></tr></thead>
        <tbody>${active.map((l) => `
          <tr>
            <td><strong>${esc(l.book_title)}</strong><div class="hint">${esc(l.book_author)}</div></td>
            <td>${fmtDate(l.borrow_date)}</td>
            <td>${fmtDate(l.due_date)}</td>
            <td>${l.is_overdue
              ? `<span class="badge late">${l.days_overdue} day(s) late · ${money(l.current_fine)}</span>`
              : '<span class="badge ok">On time</span>'}</td>
            <td class="actions"><button class="btn small primary" data-return="${l.id}">Return book</button></td>
          </tr>`).join('')}
        </tbody></table>`
    : '<div class="empty">You have no books out. Find one under "Find books".</div>';

  $('loan-history').innerHTML = history.length
    ? `<table>
        <thead><tr><th>Book</th><th>Borrowed</th><th>Returned</th><th>Result</th></tr></thead>
        <tbody>${history.map((l) => `
          <tr>
            <td>${esc(l.book_title)}</td>
            <td>${fmtDate(l.borrow_date)}</td>
            <td>${fmtDate(l.return_date)}</td>
            <td>${l.reward_earned
              ? `<span class="badge reward">+${l.reward_earned} points</span>`
              : `<span class="badge late">Fine ${money(l.fine)} ${l.fine_paid ? '(paid)' : '(unpaid)'}</span>`}</td>
          </tr>`).join('')}
        </tbody></table>`
    : '<div class="empty">Returned books will appear here.</div>';

  const unpaid = history.filter((l) => l.fine > 0 && !l.fine_paid).reduce((s, l) => s + l.fine, 0);
  $('fine-notice').innerHTML = unpaid
    ? `<div class="notice error">You owe ${money(unpaid)} in fines. Pay at the library desk to borrow again.</div>`
    : '';
}

$('active-loans').addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-return]');
  if (!btn) return;
  btn.disabled = true;
  const r = await run(
    () => api(`/borrowals/${btn.dataset.return}/return`, { method: 'POST' }),
    (res) => res.reward
      ? `Returned on time. You earned ${res.reward} points!`
      : `Returned ${res.lateDays} day(s) late. Fine: ${money(res.fine)}.`,
    'reward'
  );
  await reloadAll();
  if (!r) btn.disabled = false;
});

// ---------- Notifications (MongoDB) ----------
async function loadNotes() {
  const data = await api('/notifications');
  const unread = data.items.filter((n) => !n.read).length;
  $('note-count').hidden = unread === 0;
  $('note-count').textContent = unread;

  if (!data.available) {
    $('notes').innerHTML = '<div class="empty">Notifications are switched off because the notification database is not connected.</div>';
    return data;
  }
  $('notes').innerHTML = data.items.length
    ? `<ul class="note-list">${data.items.map((n) => `
        <li class="${n.read ? '' : 'unread'}">
          <span class="badge ${n.type === 'fine' ? 'late' : n.type === 'reward' ? 'reward' : ''}">${esc(n.type)}</span>
          <span>${esc(n.message)}</span>
          <time>${fmtDateTime(n.createdAt)}</time>
        </li>`).join('')}</ul>`
    : '<div class="empty">No notifications yet. Borrow or return a book and updates show up here.</div>';
  return data;
}

// ---------- Tabs & startup ----------
const showTab = setupTabs($('tabs'), async (name) => {
  if (name === 'notes') {
    const data = await loadNotes();
    if (data.items.some((n) => !n.read)) {
      await api('/notifications/read', { method: 'POST' });
      $('note-count').hidden = true;
    }
  }
});

async function reloadAll() {
  try {
    const user = await refreshUser();
    await loadLoans();
    renderSummary(user);
    await loadBooks();
    await loadNotes();
  } catch (err) {
    toast(err.message, 'error');
  }
}

(async function start() {
  if (!me) return;
  await loadRules();
  await loadSections();
  await reloadAll();
})();
