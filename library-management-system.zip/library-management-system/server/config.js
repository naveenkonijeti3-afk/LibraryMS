require('dotenv').config();
const path = require('path');

const num = (value, fallback) =>
  value === undefined || value === '' || Number.isNaN(Number(value)) ? fallback : Number(value);

module.exports = {
  PORT: num(process.env.PORT, 3000),
  JWT_SECRET: process.env.JWT_SECRET || 'dev-only-secret-change-me',
  JWT_EXPIRES: '8h',

  SQLITE_PATH: process.env.SQLITE_PATH
    ? path.resolve(process.env.SQLITE_PATH)
    : path.join(__dirname, '..', 'data', 'library.db'),
  MONGO_URI: process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/library',

  ADMIN_NAME: process.env.ADMIN_NAME || 'Head Librarian',
  ADMIN_EMAIL: (process.env.ADMIN_EMAIL || 'librarian@library.com').toLowerCase(),
  ADMIN_PASSWORD: process.env.ADMIN_PASSWORD || 'librarian123',

  LOAN_DAYS: num(process.env.LOAN_DAYS, 14),
  MAX_BOOKS: num(process.env.MAX_BOOKS_PER_STUDENT, 3),
  FINE_PER_DAY: num(process.env.FINE_PER_DAY, 5),
  REWARD_POINTS: num(process.env.REWARD_POINTS, 10),
  CURRENCY: process.env.CURRENCY || '₹',
};
