const express = require('express');
const db = require('../db/sql');
const config = require('../config');
const { requireRole } = require('../middleware/auth');
const { logActivity, notify } = require('../utils/logger');
const { today, addDays, daysLate, fineFor, httpError } = require('../utils/rules');

const router = express.Router(); // mounted behind authenticate

const BASE = `
  SELECT br.*,
         b.title  AS book_title,  b.author AS book_author,
         s.name   AS section_name,
         u.name   AS student_name, u.roll_no AS student_roll
  FROM borrowals br
  JOIN books    b ON b.id = br.book_id
  JOIN sections s ON s.id = b.section_id
  JOIN users    u ON u.id = br.user_id`;

// Adds live overdue / fine information to a borrowal row.
function decorate(row) {
  if (row.status === 'borrowed') {
    const late = daysLate(row.due_date, today());
    row.days_overdue = late;
    row.is_overdue = late > 0;
    row.current_fine = fineFor(late); // grows daily until returned
  } else {
    row.days_overdue = daysLate(row.due_date, row.return_date);
    row.is_overdue = false;
    row.current_fine = row.fine;
  }
  return row;
}

// ---------- Borrow ----------
const borrowTx = db.transaction((userId, bookId) => {
  const student = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'student'").get(userId);
  if (!student) throw httpError(404, 'Student not found.');

  const book = db.prepare('SELECT * FROM books WHERE id = ?').get(bookId);
  if (!book) throw httpError(404, 'Book not found.');
  if (book.available_copies < 1) throw httpError(409, 'No copies of this book are available right now.');

  const { active } = db
    .prepare("SELECT COUNT(*) AS active FROM borrowals WHERE user_id = ? AND status = 'borrowed'")
    .get(userId);
  if (active >= config.MAX_BOOKS) {
    throw httpError(409, `Limit reached: ${config.MAX_BOOKS} books at a time. Return one to borrow another.`);
  }

  const dup = db
    .prepare("SELECT id FROM borrowals WHERE user_id = ? AND book_id = ? AND status = 'borrowed'")
    .get(userId, bookId);
  if (dup) throw httpError(409, 'You already have a copy of this book.');

  const { unpaid } = db
    .prepare(
      'SELECT COALESCE(SUM(fine), 0) AS unpaid FROM borrowals WHERE user_id = ? AND fine > 0 AND fine_paid = 0'
    )
    .get(userId);
  if (unpaid > 0) {
    throw httpError(403, `Pay your outstanding fine of ${config.CURRENCY}${unpaid} at the desk before borrowing.`);
  }

  const borrowDate = today();
  const dueDate = addDays(borrowDate, config.LOAN_DAYS);
  const info = db
    .prepare('INSERT INTO borrowals (user_id, book_id, borrow_date, due_date) VALUES (?, ?, ?, ?)')
    .run(userId, bookId, borrowDate, dueDate);
  db.prepare('UPDATE books SET available_copies = available_copies - 1 WHERE id = ?').run(bookId);

  return { id: info.lastInsertRowid, student, book, borrowDate, dueDate };
});

// POST /api/borrowals  { bookId }  (student)  or  { bookId, studentId }  (librarian)
router.post('/', (req, res) => {
  const bookId = Number(req.body && req.body.bookId);
  if (!bookId) throw httpError(400, 'Choose a book.');

  let userId = req.user.id;
  if (req.user.role === 'librarian') {
    userId = Number(req.body.studentId);
    if (!userId) throw httpError(400, 'Choose a student.');
  }

  const result = borrowTx(userId, bookId);
  logActivity(req.user, 'book_borrowed', {
    student: result.student.name,
    book: result.book.title,
    dueDate: result.dueDate,
  });
  notify(userId, `You borrowed "${result.book.title}". Return it by ${result.dueDate}.`, 'info');
  res.status(201).json({ id: result.id, dueDate: result.dueDate, title: result.book.title });
});

// ---------- Return ----------
const returnTx = db.transaction((borrowalId, actor) => {
  const br = db.prepare('SELECT * FROM borrowals WHERE id = ?').get(borrowalId);
  if (!br) throw httpError(404, 'Borrowal not found.');
  if (actor.role === 'student' && br.user_id !== actor.id) throw httpError(403, 'This is not your borrowal.');
  if (br.status !== 'borrowed') throw httpError(409, 'This book has already been returned.');

  const returnDate = today();
  const lateDays = daysLate(br.due_date, returnDate);
  const fine = fineFor(lateDays);
  const reward = lateDays === 0 ? config.REWARD_POINTS : 0;

  db.prepare(
    `UPDATE borrowals
        SET status = 'returned', return_date = ?, fine = ?, fine_paid = ?, reward_earned = ?
      WHERE id = ?`
  ).run(returnDate, fine, fine > 0 ? 0 : 1, reward, br.id);
  db.prepare('UPDATE books SET available_copies = available_copies + 1 WHERE id = ?').run(br.book_id);
  if (reward > 0) {
    db.prepare('UPDATE users SET reward_points = reward_points + ? WHERE id = ?').run(reward, br.user_id);
  }

  const book = db.prepare('SELECT title FROM books WHERE id = ?').get(br.book_id);
  const student = db.prepare('SELECT id, name FROM users WHERE id = ?').get(br.user_id);
  return { book, student, lateDays, fine, reward };
});

// POST /api/borrowals/:id/return  (the student themself, or the librarian)
router.post('/:id/return', (req, res) => {
  const r = returnTx(req.params.id, req.user);
  const cur = config.CURRENCY;

  if (r.reward > 0) {
    notify(r.student.id, `You returned "${r.book.title}" on time and earned ${r.reward} reward points.`, 'reward');
  } else {
    notify(
      r.student.id,
      `"${r.book.title}" came back ${r.lateDays} day(s) late. A fine of ${cur}${r.fine} applies.`,
      'fine'
    );
  }
  logActivity(req.user, 'book_returned', {
    student: r.student.name,
    book: r.book.title,
    lateDays: r.lateDays,
    fine: r.fine,
    reward: r.reward,
  });

  res.json({ title: r.book.title, lateDays: r.lateDays, fine: r.fine, reward: r.reward });
});

// ---------- Read ----------
// GET /api/borrowals/mine  (student's own history)
router.get('/mine', (req, res) => {
  const rows = db
    .prepare(`${BASE} WHERE br.user_id = ? ORDER BY (br.status = 'borrowed') DESC, br.id DESC`)
    .all(req.user.id);
  res.json(rows.map(decorate));
});

// GET /api/borrowals?status=borrowed|overdue|returned  (librarian)
router.get('/', requireRole('librarian'), (req, res) => {
  const rows = db.prepare(`${BASE} ORDER BY br.id DESC`).all().map(decorate);
  const { status } = req.query;
  if (status === 'overdue') return res.json(rows.filter((r) => r.is_overdue));
  if (status === 'borrowed' || status === 'returned') return res.json(rows.filter((r) => r.status === status));
  res.json(rows);
});

// POST /api/borrowals/:id/pay-fine  (librarian records that the fine was paid)
router.post('/:id/pay-fine', requireRole('librarian'), (req, res) => {
  const br = db.prepare('SELECT * FROM borrowals WHERE id = ?').get(req.params.id);
  if (!br) throw httpError(404, 'Borrowal not found.');
  if (br.status !== 'returned' || br.fine <= 0) throw httpError(409, 'There is no fine to collect on this borrowal.');
  if (br.fine_paid) throw httpError(409, 'This fine is already marked as paid.');

  db.prepare('UPDATE borrowals SET fine_paid = 1 WHERE id = ?').run(br.id);
  logActivity(req.user, 'fine_paid', { borrowalId: br.id, amount: br.fine });
  notify(br.user_id, `Your fine of ${config.CURRENCY}${br.fine} was marked as paid. You can borrow again.`, 'info');
  res.json({ ok: true });
});

module.exports = router;
