const express = require('express');
const db = require('../db/sql');
const { today } = require('../utils/rules');

const router = express.Router(); // librarian only

// GET /api/stats – numbers for the librarian dashboard
router.get('/', (req, res) => {
  const one = (sql, ...p) => db.prepare(sql).get(...p);

  const books = one(
    `SELECT COUNT(*) AS titles,
            COALESCE(SUM(total_copies), 0)     AS copies,
            COALESCE(SUM(available_copies), 0) AS available
     FROM books`
  );
  const students = one("SELECT COUNT(*) AS c FROM users WHERE role = 'student'").c;
  const onLoan = one("SELECT COUNT(*) AS c FROM borrowals WHERE status = 'borrowed'").c;
  const overdue = one("SELECT COUNT(*) AS c FROM borrowals WHERE status = 'borrowed' AND due_date < ?", today()).c;
  const unpaid = one("SELECT COALESCE(SUM(fine), 0) AS t FROM borrowals WHERE fine > 0 AND fine_paid = 0").t;
  const returnedToday = one("SELECT COUNT(*) AS c FROM borrowals WHERE return_date = ?", today()).c;
  const borrowedToday = one("SELECT COUNT(*) AS c FROM borrowals WHERE borrow_date = ?", today()).c;

  const sections = db
    .prepare(
      `SELECT s.id, s.name,
              COUNT(b.id)                          AS titles,
              COALESCE(SUM(b.total_copies), 0)     AS total_copies,
              COALESCE(SUM(b.available_copies), 0) AS available_copies
       FROM sections s LEFT JOIN books b ON b.section_id = s.id
       GROUP BY s.id ORDER BY s.name`
    )
    .all();

  res.json({
    titles: books.titles,
    copies: books.copies,
    available: books.available,
    students,
    onLoan,
    overdue,
    unpaidFines: unpaid,
    returnedToday,
    borrowedToday,
    sections,
  });
});

module.exports = router;
