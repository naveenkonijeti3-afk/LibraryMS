const express = require('express');
const bcrypt = require('bcryptjs');
const db = require('../db/sql');
const { logActivity } = require('../utils/logger');
const { httpError } = require('../utils/rules');

const router = express.Router(); // mounted behind authenticate + requireRole('librarian')

// GET /api/students
router.get('/', (req, res) => {
  const rows = db
    .prepare(
      `SELECT u.id, u.name, u.email, u.roll_no, u.reward_points, u.created_at,
              (SELECT COUNT(*) FROM borrowals
                 WHERE user_id = u.id AND status = 'borrowed') AS active_borrowals,
              (SELECT COALESCE(SUM(fine), 0) FROM borrowals
                 WHERE user_id = u.id AND fine > 0 AND fine_paid = 0) AS unpaid_fines
       FROM users u
       WHERE u.role = 'student'
       ORDER BY u.name`
    )
    .all();
  res.json(rows);
});

// POST /api/students  { name, email, roll_no, password }
router.post('/', (req, res) => {
  const body = req.body || {};
  const name = String(body.name || '').trim();
  const email = String(body.email || '').trim().toLowerCase();
  const rollNo = String(body.roll_no || '').trim() || null;
  const password = String(body.password || '');

  if (!name || !email) throw httpError(400, 'Name and email are required.');
  if (!/^\S+@\S+\.\S+$/.test(email)) throw httpError(400, 'Enter a valid email address.');
  if (password.length < 6) throw httpError(400, 'Password must be at least 6 characters.');

  try {
    const info = db
      .prepare(
        "INSERT INTO users (name, email, password_hash, role, roll_no) VALUES (?, ?, ?, 'student', ?)"
      )
      .run(name, email, bcrypt.hashSync(password, 10), rollNo);
    logActivity(req.user, 'student_added', { name, email });
    res.status(201).json({ id: info.lastInsertRowid, name, email, roll_no: rollNo });
  } catch (err) {
    if (String(err.message).includes('UNIQUE')) {
      throw httpError(409, 'A user with this email or roll number already exists.');
    }
    throw err;
  }
});

// DELETE /api/students/:id – blocked while books or fines are outstanding
router.delete('/:id', (req, res) => {
  const student = db
    .prepare("SELECT * FROM users WHERE id = ? AND role = 'student'")
    .get(req.params.id);
  if (!student) throw httpError(404, 'Student not found.');

  const { active } = db
    .prepare("SELECT COUNT(*) AS active FROM borrowals WHERE user_id = ? AND status = 'borrowed'")
    .get(student.id);
  if (active > 0) throw httpError(409, `${student.name} still has ${active} book(s) to return.`);

  const { unpaid } = db
    .prepare(
      'SELECT COALESCE(SUM(fine), 0) AS unpaid FROM borrowals WHERE user_id = ? AND fine > 0 AND fine_paid = 0'
    )
    .get(student.id);
  if (unpaid > 0) throw httpError(409, `${student.name} has an unpaid fine. Mark it as paid first.`);

  db.prepare('DELETE FROM users WHERE id = ?').run(student.id);
  logActivity(req.user, 'student_removed', { name: student.name, email: student.email });
  res.json({ ok: true });
});

module.exports = router;
