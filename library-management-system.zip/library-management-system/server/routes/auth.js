const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db/sql');
const config = require('../config');
const { authenticate } = require('../middleware/auth');
const { logActivity } = require('../utils/logger');
const { httpError } = require('../utils/rules');

const router = express.Router();

// POST /api/auth/login  { email, password, role: 'student' | 'librarian' }
router.post('/login', (req, res) => {
  const { email, password, role } = req.body || {};
  if (!email || !password || !['student', 'librarian'].includes(role)) {
    throw httpError(400, 'Enter your email, password and choose a login type.');
  }

  const user = db
    .prepare('SELECT * FROM users WHERE email = ? AND role = ?')
    .get(String(email).trim().toLowerCase(), role);

  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    throw httpError(401, 'Email or password is incorrect for this login type.');
  }

  const token = jwt.sign({ id: user.id, role: user.role }, config.JWT_SECRET, {
    expiresIn: config.JWT_EXPIRES,
  });
  const { password_hash, ...safeUser } = user;
  logActivity(safeUser, 'login', {});
  res.json({ token, user: safeUser });
});

// GET /api/auth/me  – fresh copy of the signed-in user (reward points change)
router.get('/me', authenticate, (req, res) => res.json({ user: req.user }));

module.exports = router;
