const express = require('express');
const db = require('../db/sql');
const { requireRole } = require('../middleware/auth');
const { logActivity } = require('../utils/logger');
const { httpError } = require('../utils/rules');

const router = express.Router();

// GET /api/sections – every section with its book counts
router.get('/', (req, res) => {
  const rows = db
    .prepare(
      `SELECT s.id, s.name, s.description,
              COUNT(b.id)                          AS titles,
              COALESCE(SUM(b.total_copies), 0)     AS total_copies,
              COALESCE(SUM(b.available_copies), 0) AS available_copies
       FROM sections s
       LEFT JOIN books b ON b.section_id = s.id
       GROUP BY s.id
       ORDER BY s.name`
    )
    .all();
  res.json(rows);
});

// POST /api/sections  { name, description }
router.post('/', requireRole('librarian'), (req, res) => {
  const name = String((req.body && req.body.name) || '').trim();
  const description = String((req.body && req.body.description) || '').trim();
  if (!name) throw httpError(400, 'Enter a section name.');

  try {
    const info = db
      .prepare('INSERT INTO sections (name, description) VALUES (?, ?)')
      .run(name, description || null);
    logActivity(req.user, 'section_added', { name });
    res.status(201).json({ id: info.lastInsertRowid, name, description });
  } catch (err) {
    if (String(err.message).includes('UNIQUE')) throw httpError(409, 'A section with this name already exists.');
    throw err;
  }
});

// DELETE /api/sections/:id – only when it holds no books
router.delete('/:id', requireRole('librarian'), (req, res) => {
  const section = db.prepare('SELECT * FROM sections WHERE id = ?').get(req.params.id);
  if (!section) throw httpError(404, 'Section not found.');

  const { c } = db.prepare('SELECT COUNT(*) AS c FROM books WHERE section_id = ?').get(section.id);
  if (c > 0) throw httpError(409, `Move or remove the ${c} book title(s) in this section first.`);

  db.prepare('DELETE FROM sections WHERE id = ?').run(section.id);
  logActivity(req.user, 'section_removed', { name: section.name });
  res.json({ ok: true });
});

module.exports = router;
