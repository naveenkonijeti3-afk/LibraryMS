const express = require('express');
const db = require('../db/sql');
const { requireRole } = require('../middleware/auth');
const { logActivity } = require('../utils/logger');
const { httpError } = require('../utils/rules');

const router = express.Router();

const BOOK_SELECT = `
  SELECT b.*, s.name AS section_name
  FROM books b
  JOIN sections s ON s.id = b.section_id`;

// GET /api/books?q=search&section=ID
router.get('/', (req, res) => {
  const where = [];
  const params = [];

  if (req.query.q) {
    where.push('(b.title LIKE ? OR b.author LIKE ? OR b.isbn LIKE ?)');
    const like = `%${req.query.q}%`;
    params.push(like, like, like);
  }
  if (req.query.section) {
    where.push('b.section_id = ?');
    params.push(req.query.section);
  }

  const sql = `${BOOK_SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY b.title`;
  res.json(db.prepare(sql).all(...params));
});

function readBookBody(body = {}) {
  const title = String(body.title || '').trim();
  const author = String(body.author || '').trim();
  const isbn = String(body.isbn || '').trim() || null;
  const sectionId = Number(body.section_id);
  const total = Number(body.total_copies);

  if (!title || !author) throw httpError(400, 'Title and author are required.');
  if (!sectionId || !db.prepare('SELECT id FROM sections WHERE id = ?').get(sectionId)) {
    throw httpError(400, 'Choose a section for this book.');
  }
  if (!Number.isInteger(total) || total < 0) throw httpError(400, 'Copies must be a whole number, 0 or more.');
  return { title, author, isbn, sectionId, total };
}

function uniqueIsbn(err) {
  if (String(err.message).includes('UNIQUE')) throw httpError(409, 'A book with this ISBN already exists.');
  throw err;
}

// POST /api/books
router.post('/', requireRole('librarian'), (req, res) => {
  const b = readBookBody(req.body);
  try {
    const info = db
      .prepare(
        `INSERT INTO books (title, author, isbn, section_id, total_copies, available_copies)
         VALUES (?, ?, ?, ?, ?, ?)`
      )
      .run(b.title, b.author, b.isbn, b.sectionId, b.total, b.total);
    logActivity(req.user, 'book_added', { title: b.title, copies: b.total });
    res.status(201).json(db.prepare(`${BOOK_SELECT} WHERE b.id = ?`).get(info.lastInsertRowid));
  } catch (err) {
    uniqueIsbn(err);
  }
});

// PUT /api/books/:id – edit details and copy count
router.put('/:id', requireRole('librarian'), (req, res) => {
  const book = db.prepare('SELECT * FROM books WHERE id = ?').get(req.params.id);
  if (!book) throw httpError(404, 'Book not found.');

  const b = readBookBody(req.body);
  const onLoan = book.total_copies - book.available_copies;
  if (b.total < onLoan) {
    throw httpError(409, `${onLoan} copies are on loan, so the total cannot be below ${onLoan}.`);
  }

  try {
    db.prepare(
      `UPDATE books SET title = ?, author = ?, isbn = ?, section_id = ?,
                        total_copies = ?, available_copies = ?
       WHERE id = ?`
    ).run(b.title, b.author, b.isbn, b.sectionId, b.total, b.total - onLoan, book.id);
    logActivity(req.user, 'book_updated', { title: b.title, copies: b.total });
    res.json(db.prepare(`${BOOK_SELECT} WHERE b.id = ?`).get(book.id));
  } catch (err) {
    uniqueIsbn(err);
  }
});

// DELETE /api/books/:id – blocked while copies are on loan
router.delete('/:id', requireRole('librarian'), (req, res) => {
  const book = db.prepare('SELECT * FROM books WHERE id = ?').get(req.params.id);
  if (!book) throw httpError(404, 'Book not found.');

  const { c } = db
    .prepare("SELECT COUNT(*) AS c FROM borrowals WHERE book_id = ? AND status = 'borrowed'")
    .get(book.id);
  if (c > 0) throw httpError(409, `${c} cop${c === 1 ? 'y is' : 'ies are'} still on loan. Wait for the return first.`);

  db.prepare('DELETE FROM books WHERE id = ?').run(book.id);
  logActivity(req.user, 'book_removed', { title: book.title });
  res.json({ ok: true });
});

module.exports = router;
