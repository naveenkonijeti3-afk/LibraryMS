// Routes backed by MongoDB: activity log and notifications.
const express = require('express');
const { ActivityLog, Notification, isConnected } = require('../db/mongo');
const { requireRole } = require('../middleware/auth');

const router = express.Router(); // mounted behind authenticate

// Express 4 does not catch rejected promises, so forward them to the error handler.
const wrap = (fn) => (req, res, next) => fn(req, res, next).catch(next);

// GET /api/activity  (librarian) – latest 100 events
router.get('/activity', requireRole('librarian'), wrap(async (req, res) => {
  if (!isConnected()) return res.json({ available: false, items: [] });
  const items = await ActivityLog.find().sort({ createdAt: -1 }).limit(100).lean();
  res.json({ available: true, items });
}));

// GET /api/notifications  (own notifications)
router.get('/notifications', wrap(async (req, res) => {
  if (!isConnected()) return res.json({ available: false, items: [] });
  const items = await Notification.find({ userId: req.user.id }).sort({ createdAt: -1 }).limit(50).lean();
  res.json({ available: true, items });
}));

// POST /api/notifications/read  – mark all as read
router.post('/notifications/read', wrap(async (req, res) => {
  if (isConnected()) await Notification.updateMany({ userId: req.user.id, read: false }, { read: true });
  res.json({ ok: true });
}));

module.exports = router;
