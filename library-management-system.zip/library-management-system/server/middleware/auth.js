const jwt = require('jsonwebtoken');
const db = require('../db/sql');
const config = require('../config');

// Reads the Bearer token, loads the user from SQL and attaches it to req.user.
// Loading from the database means a removed student is locked out immediately.
function authenticate(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'Please sign in.' });

  try {
    const payload = jwt.verify(token, config.JWT_SECRET);
    const user = db
      .prepare('SELECT id, name, email, role, roll_no, reward_points FROM users WHERE id = ?')
      .get(payload.id);
    if (!user) return res.status(401).json({ error: 'Your account no longer exists.' });
    req.user = user;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Your session has expired. Please sign in again.' });
  }
}

const requireRole = (role) => (req, res, next) =>
  req.user && req.user.role === role
    ? next()
    : res.status(403).json({ error: 'You do not have access to this action.' });

module.exports = { authenticate, requireRole };
