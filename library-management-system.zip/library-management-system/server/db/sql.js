// SQL database (SQLite). Holds the relational, transactional data:
// users, sections, books and borrowals.
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const fs = require('fs');
const path = require('path');
const config = require('../config');

fs.mkdirSync(path.dirname(config.SQLITE_PATH), { recursive: true });

const db = new Database(config.SQLITE_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function init() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      name          TEXT NOT NULL,
      email         TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      role          TEXT NOT NULL CHECK (role IN ('student', 'librarian')),
      roll_no       TEXT UNIQUE,
      reward_points INTEGER NOT NULL DEFAULT 0,
      created_at    TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS sections (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      name        TEXT NOT NULL UNIQUE,
      description TEXT
    );

    CREATE TABLE IF NOT EXISTS books (
      id               INTEGER PRIMARY KEY AUTOINCREMENT,
      title            TEXT NOT NULL,
      author           TEXT NOT NULL,
      isbn             TEXT UNIQUE,
      section_id       INTEGER NOT NULL REFERENCES sections(id),
      total_copies     INTEGER NOT NULL DEFAULT 1 CHECK (total_copies >= 0),
      available_copies INTEGER NOT NULL DEFAULT 1 CHECK (available_copies >= 0),
      created_at       TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS borrowals (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id       INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      book_id       INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
      borrow_date   TEXT NOT NULL,            -- YYYY-MM-DD
      due_date      TEXT NOT NULL,            -- YYYY-MM-DD
      return_date   TEXT,                     -- YYYY-MM-DD, null while borrowed
      fine          REAL NOT NULL DEFAULT 0,
      fine_paid     INTEGER NOT NULL DEFAULT 0,
      reward_earned INTEGER NOT NULL DEFAULT 0,
      status        TEXT NOT NULL DEFAULT 'borrowed' CHECK (status IN ('borrowed', 'returned'))
    );

    CREATE INDEX IF NOT EXISTS idx_borrowals_user   ON borrowals(user_id, status);
    CREATE INDEX IF NOT EXISTS idx_borrowals_book   ON borrowals(book_id, status);
    CREATE INDEX IF NOT EXISTS idx_books_section    ON books(section_id);
  `);

  ensureLibrarian();
}

// Creates the first librarian account from .env if none exists yet.
function ensureLibrarian() {
  const existing = db.prepare("SELECT id FROM users WHERE role = 'librarian' LIMIT 1").get();
  if (existing) return;
  db.prepare(
    "INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, 'librarian')"
  ).run(config.ADMIN_NAME, config.ADMIN_EMAIL, bcrypt.hashSync(config.ADMIN_PASSWORD, 10));
  console.log(`Created librarian account: ${config.ADMIN_EMAIL}`);
}

module.exports = db;
module.exports.init = init;
