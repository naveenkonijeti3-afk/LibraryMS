// NoSQL database (MongoDB). Holds flexible, append-only data:
// the activity log (audit trail) and per-student notifications.
// If MongoDB is unreachable the rest of the app keeps working.
const mongoose = require('mongoose');
const config = require('../config');

mongoose.set('bufferCommands', false);

const activitySchema = new mongoose.Schema(
  {
    action: { type: String, required: true, index: true },
    actorId: Number,
    actorName: String,
    role: String,
    details: mongoose.Schema.Types.Mixed,
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);

const notificationSchema = new mongoose.Schema(
  {
    userId: { type: Number, required: true, index: true },
    message: { type: String, required: true },
    type: { type: String, enum: ['info', 'reward', 'fine'], default: 'info' },
    read: { type: Boolean, default: false },
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);

const ActivityLog = mongoose.model('ActivityLog', activitySchema);
const Notification = mongoose.model('Notification', notificationSchema);

const isConnected = () => mongoose.connection.readyState === 1;

async function connectMongo() {
  try {
    await mongoose.connect(config.MONGO_URI, { serverSelectionTimeoutMS: 4000 });
    console.log('MongoDB connected (activity log + notifications enabled)');
  } catch (err) {
    console.warn(`MongoDB not available (${err.message}).`);
    console.warn('The app will run without activity logs and notifications.');
  }
}

module.exports = { connectMongo, isConnected, ActivityLog, Notification };
