// Adds sample sections, books and students so you can try the app straight away.
//   npm run seed          – only runs if there are no sections yet
//   npm run seed:reset    – wipes books, sections, students and borrowals first
const bcrypt = require('bcryptjs');
const db = require('./db/sql');
const { today, addDays } = require('./utils/rules');
const config = require('./config');

db.init();
const reset = process.argv.includes('--reset');

if (reset) {
  db.exec("DELETE FROM borrowals; DELETE FROM books; DELETE FROM sections; DELETE FROM users WHERE role = 'student';");
  console.log('Cleared existing library data.');
} else if (db.prepare('SELECT COUNT(*) AS c FROM sections').get().c > 0) {
  console.log('Data already exists. Use "npm run seed:reset" to start fresh.');
  process.exit(0);
}

const sections = {
  'Computer Science': 'Programming, algorithms, databases',
  Fiction: 'Novels and short stories',
  Science: 'Physics, chemistry, biology',
  Mathematics: 'Pure and applied mathematics',
  History: 'World and regional history',
};
const addSection = db.prepare('INSERT INTO sections (name, description) VALUES (?, ?)');
const sectionId = {};
for (const [name, desc] of Object.entries(sections)) sectionId[name] = addSection.run(name, desc).lastInsertRowid;

const books = [
  ['Introduction to Algorithms', 'Thomas H. Cormen', '9780262046305', 'Computer Science', 4],
  ['Clean Code', 'Robert C. Martin', '9780132350884', 'Computer Science', 3],
  ['Database System Concepts', 'Abraham Silberschatz', '9780078022159', 'Computer Science', 3],
  ['Eloquent JavaScript', 'Marijn Haverbeke', '9781593279509', 'Computer Science', 2],
  ['To Kill a Mockingbird', 'Harper Lee', '9780061120084', 'Fiction', 3],
  ['The Alchemist', 'Paulo Coelho', '9780062315007', 'Fiction', 5],
  ['1984', 'George Orwell', '9780451524935', 'Fiction', 4],
  ['A Brief History of Time', 'Stephen Hawking', '9780553380163', 'Science', 2],
  ['The Selfish Gene', 'Richard Dawkins', '9780198788607', 'Science', 2],
  ['Calculus', 'James Stewart', '9781285740621', 'Mathematics', 3],
  ['Linear Algebra Done Right', 'Sheldon Axler', '9783319110790', 'Mathematics', 2],
  ['Sapiens', 'Yuval Noah Harari', '9780062316097', 'History', 4],
  ['The Discovery of India', 'Jawaharlal Nehru', '9780143031031', 'History', 2],
];
const addBook = db.prepare(
  'INSERT INTO books (title, author, isbn, section_id, total_copies, available_copies) VALUES (?, ?, ?, ?, ?, ?)'
);
const bookId = {};
for (const [title, author, isbn, section, copies] of books) {
  bookId[title] = addBook.run(title, author, isbn, sectionId[section], copies, copies).lastInsertRowid;
}

const addStudent = db.prepare(
  "INSERT INTO users (name, email, password_hash, role, roll_no) VALUES (?, ?, ?, 'student', ?)"
);
const hash = bcrypt.hashSync('student123', 10);
const asha = addStudent.run('Asha Verma', 'asha@student.com', hash, 'CS2101').lastInsertRowid;
const ravi = addStudent.run('Ravi Kumar', 'ravi@student.com', hash, 'CS2102').lastInsertRowid;
addStudent.run('Meera Nair', 'meera@student.com', hash, 'CS2103');

// One overdue loan (so you can see the fine) and one on-time return (so you can see a reward).
const t = today();
const addBorrowal = db.prepare(
  `INSERT INTO borrowals (user_id, book_id, borrow_date, due_date, return_date, fine, fine_paid, reward_earned, status)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
);
const take = db.prepare('UPDATE books SET available_copies = available_copies - 1 WHERE id = ?');

addBorrowal.run(ravi, bookId['Clean Code'], addDays(t, -20), addDays(t, -20 + config.LOAN_DAYS), null, 0, 0, 0, 'borrowed');
take.run(bookId['Clean Code']);

addBorrowal.run(asha, bookId['1984'], addDays(t, -10), addDays(t, -10 + config.LOAN_DAYS), addDays(t, -3), 0, 1, config.REWARD_POINTS, 'returned');
db.prepare('UPDATE users SET reward_points = ? WHERE id = ?').run(config.REWARD_POINTS, asha);

addBorrowal.run(asha, bookId['The Alchemist'], addDays(t, -2), addDays(t, -2 + config.LOAN_DAYS), null, 0, 0, 0, 'borrowed');
take.run(bookId['The Alchemist']);

console.log('Sample data added.');
console.log(`Librarian:  ${config.ADMIN_EMAIL} / ${config.ADMIN_PASSWORD}`);
console.log('Students:   asha@student.com, ravi@student.com, meera@student.com  (password: student123)');
