const path = require('path');
const express = require('express');
const cors = require('cors');

const config = require('./config');
const db = require('./db/sql');
const { connectMongo } = require('./db/mongo');
const { authenticate, requireRole } = require('./middleware/auth');

db.init();

const app = express();
app.use(cors());
app.use(express.json());

// Public: the library rules, so the front end can show them.
app.get('/api/config', (req, res) =>
  res.json({
    loanDays: config.LOAN_DAYS,
    maxBooks: config.MAX_BOOKS,
    finePerDay: config.FINE_PER_DAY,
    rewardPoints: config.REWARD_POINTS,
    currency: config.CURRENCY,
  })
);

app.use('/api/auth', require('./routes/auth'));

const librarianOnly = [authenticate, requireRole('librarian')];
app.use('/api/sections', authenticate, require('./routes/sections'));
app.use('/api/books', authenticate, require('./routes/books'));
app.use('/api/borrowals', authenticate, require('./routes/borrowals'));
app.use('/api/students', ...librarianOnly, require('./routes/students'));
app.use('/api/stats', ...librarianOnly, require('./routes/stats'));
app.use('/api', authenticate, require('./routes/misc'));

app.use('/api', (req, res) => res.status(404).json({ error: 'Not found.' }));

// Front end (plain HTML/CSS/JS)
app.use(express.static(path.join(__dirname, '..', 'public')));

// Central error handler: routes throw httpError(status, message)
app.use((err, req, res, next) => {
  const status = err.status || 500;
  if (status === 500) console.error(err);
  res.status(status).json({ error: status === 500 ? 'Something went wrong on the server.' : err.message });
});

connectMongo().finally(() => {
  app.listen(config.PORT, () => {
    console.log(`Library app running at http://localhost:${config.PORT}`);
  });
});
