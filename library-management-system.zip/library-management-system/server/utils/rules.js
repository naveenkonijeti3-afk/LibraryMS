// Small helpers for dates, fines and errors.
const config = require('../config');

const DAY_MS = 24 * 60 * 60 * 1000;

const today = () => new Date().toISOString().slice(0, 10);

function addDays(dateStr, days) {
  const d = new Date(`${dateStr}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

// Whole days that `onDate` is after `dueDate` (0 if on time or early).
function daysLate(dueDate, onDate) {
  const diff = Math.round((Date.parse(onDate) - Date.parse(dueDate)) / DAY_MS);
  return diff > 0 ? diff : 0;
}

const fineFor = (lateDays) => lateDays * config.FINE_PER_DAY;

function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

module.exports = { today, addDays, daysLate, fineFor, httpError };
