// Writes to MongoDB without ever blocking or breaking a request.
const { ActivityLog, Notification, isConnected } = require('../db/mongo');

function logActivity(user, action, details = {}) {
  if (!isConnected()) return;
  ActivityLog.create({
    action,
    actorId: user && user.id,
    actorName: user && user.name,
    role: user && user.role,
    details,
  }).catch((err) => console.warn('Activity log failed:', err.message));
}

function notify(userId, message, type = 'info') {
  if (!isConnected()) return;
  Notification.create({ userId, message, type }).catch((err) =>
    console.warn('Notification failed:', err.message)
  );
}

module.exports = { logActivity, notify };
